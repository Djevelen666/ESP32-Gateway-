// ===================== CONFIG =====================

const CONFIG = {
  appName: "ESP32 Gateway",
  pin: "0000",

  ui: {
    fullscreen: false,
    kiosk: false,
    lockTimeout: 30,
    colors: {
      bg: "#121212",
      card: "#222222",
      menu: "#1f1f1f",
      btn: "#666666",
    },
  },

  relays: {},
  hiddenNodes: [],
};

const WS_URL =
  (location.protocol === "https:" ? "wss://" : "ws://") + location.host + "/ws";

let ws = null;
let nodes = {};
let lockTimer = null;

let logPaused = false;
const MAX_LOG_LINES = 150;

let kioskEnabled = true;
let isLocked = true;

let lastGatewayStatus = Date.now();

setInterval(() => {
  const age = Date.now() - lastGatewayStatus;

  const gw = document.getElementById("gatewayAlive");

  if (gw) {
    gw.textContent = age < 1000 ? "🟢 Live" : "🔴 Geen verbinding";
  }
}, 1500);

const STATE = {
  connected: false,
  unlocked: sessionStorage.getItem("unlocked") === "true",
};

function clearLogs() {
  document.getElementById("rxLog").innerHTML = "";
  document.getElementById("txLog").innerHTML = "";
}

function toggleLogPause() {

  logPaused = !logPaused;
  const btn = document.getElementById("pauseLogBtn");
  btn.textContent =
    logPaused ? "▶ Resume" : "⏸ Pause";
}

function copyLogs() {

  const text =
    "RX\n\n" +
    document.getElementById("rxLog").innerText +
    "\n\nTX\n\n" +
    document.getElementById("txLog").innerText;

  navigator.clipboard.writeText(text)
    .then(() => {
      console.log("Log copied");
    })
    .catch(err => {
      console.error(err);
    });
}

function addLog(type, data) {
  const box = document.getElementById(
    type === "RX" ? "rxLog" : "txLog"
  );
  if (!box) return;
  const t = new Date().toLocaleTimeString();
  const line = document.createElement("div");

  line.className =
    type === "RX" ? "log-rx" : "log-tx";
  line.textContent =
    `${t} ${JSON.stringify(data)}`;
  box.appendChild(line);

  while (box.children.length > MAX_LOG_LINES) {
    box.removeChild(box.firstChild);
  }

  if (!logPaused) {
    box.scrollTop = box.scrollHeight;
  }
}

function loadConfig() {
  const saved = localStorage.getItem("config");
  if (saved) Object.assign(CONFIG, JSON.parse(saved));

  applyConfig();
}

function saveConfig() {
  localStorage.setItem("config", JSON.stringify(CONFIG));
}

function applyConfig() {
  document.getElementById("appTitle").textContent = CONFIG.appName;

  const appName = document.getElementById("appNameInput");
  if (appName) appName.value = CONFIG.appName;

  const pin = document.getElementById("pinInput");
  if (pin) pin.value = CONFIG.pin;

  const timeout = document.getElementById("timeoutInput");
  if (timeout) timeout.value = CONFIG.ui.lockTimeout;

  Object.entries(CONFIG.ui.colors).forEach(([k, v]) => {
    document.documentElement.style.setProperty(`--${k}`, v);

    const preview = document.getElementById(`prev-${k}`);
    if (preview) preview.style.background = v;
  });

  if (CONFIG.ui.fullscreen && !document.fullscreenElement) {
    document.documentElement.requestFullscreen?.();
  }

  renderRelaySettings();
}

// ===================== INIT =====================
function connectWS() {
  if (ws) ws.close();

  ws = new WebSocket(WS_URL);

  ws.onopen = () => {
    STATE.connected = true;
    setConnectionStatus(true);
    console.log("[WS] Connected");
    checkOTA();
  };

  ws.onclose = () => {
    STATE.connected = false;
    setConnectionStatus(false);
    console.log("[WS] Disconnected");

    setTimeout(connectWS, 2000);
  };
  ws.onmessage = (event) => {
    console.log("RAW WS:", event.data);
    let data;

    try {
      data = JSON.parse(event.data);
    }
    catch (e) {
      console.error(e);
      return;
    }

    lastGatewayStatus = Date.now();

    addLog("RX", data);
    if (Array.isArray(data)) {
      updateNodes(data);
    }
    else {

      if (data.type === "status") {
        updateWifiInfo(data.wifi);
      }

      // OTA status zit direct in het JSON-object
      if (data.type === "ota" || data.firmware || data.web) {
        updateOTA(data);
      }

    }
  }

};


// ================= NAVIGATION =================

function bindNavigation() {
  const sidenav = document.getElementById("sidenav");
  const menuBtn = document.getElementById("menuBtn");
  const overlay = document.getElementById("overlay");

  if (!sidenav || !menuBtn || !overlay) {
    console.warn("[NAV] missing elements");
    return;
  }

  // OPEN/CLOSE MENU
  menuBtn.addEventListener("click", (e) => {
    e.stopPropagation();
    sidenav.classList.add("open");
    overlay.classList.add("show");
  });

  // PAGE NAVIGATION
  document.querySelectorAll("[data-page]").forEach((el) => {
    el.addEventListener("click", () => {
      const page = el.dataset.page;

      if (page) showPage(page);

      sidenav.classList.remove("open");
      overlay.classList.remove("show");
    });
  });

  // CLICK OUTSIDE CLOSE
  overlay.addEventListener("click", () => {
    sidenav.classList.remove("open");
    overlay.classList.remove("show");
  });

  document.addEventListener("click", (e) => {
    if (!sidenav.classList.contains("open")) return;

    if (!sidenav.contains(e.target) && e.target.id !== "menuBtn") {
      sidenav.classList.remove("open");
      overlay.classList.remove("show");
    }
  });
}

// ================= HEADER =================
function bindHeader() {
  const lockBtn = document.getElementById("lockBtn");

  if (lockBtn) {
    lockBtn.addEventListener("click", toggleLock);
  }

  document.querySelectorAll("[data-page='home']").forEach((el) => {
    el.addEventListener("click", () => showPage("home"));
  });
}

// ===================== LOCK =====================

let pinBuffer = "";
/*
let PIN_CODE = localStorage.getItem("pin") || "0000";
*/

function initLockscreen() {
  const display = document.getElementById("codeDisplay");

  document.querySelectorAll(".keypad button").forEach((btn) => {
    btn.addEventListener("click", () => {
      const key = btn.dataset.key;

      if (STATE.unlocked) return;

      if (key === "clear") {
        pinBuffer = "";
      } else if (key === "ok") {
        checkPIN();
      } else {
        if (pinBuffer.length < 4) pinBuffer += key;
      }

      updatePinDisplay();
    });
  });

  updatePinDisplay();
}

function updatePinDisplay() {
  const display = document.getElementById("codeDisplay");
  display.textContent = "*".repeat(pinBuffer.length).padEnd(4, "-");
}

function checkPIN() {
  if (pinBuffer === CONFIG.pin) {
    unlock();
  } else {
    pinBuffer = "";
    updatePinDisplay();
  }
}

function unlock() {
  STATE.unlocked = true;
  sessionStorage.setItem("unlocked", "true");

  document.getElementById("lockscreen").style.display = "none";

  pinBuffer = "";
  updatePinDisplay();

  resetLockTimer(); // 🔥 START TIMER

  console.log("[LOCK] Unlocked");
}

function lock() {
  STATE.unlocked = false;
  sessionStorage.removeItem("unlocked");
  if (lockTimer) clearTimeout(lockTimer);

  pinBuffer = "";
  updatePinDisplay();

  document.getElementById("lockscreen").style.display = "flex";

  console.log("[LOCK] Locked");
}

function resetUIAfterOTA() {

  console.log("[OTA] Reset UI");

  // Sluit menu
  document.getElementById("sidenav")?.classList.remove("open");
  document.getElementById("overlay")?.classList.remove("show");

  // Terug naar home
  showPage("home");

  // Lockscreen tonen
  lock();

  // OTA scherm resetten
  document.getElementById("fwProgress").style.width = "0%";
  document.getElementById("fwProgressText").textContent = "0%";

  document.getElementById("webProgress").style.width = "0%";
  document.getElementById("webProgressText").textContent = "0%";

  document.getElementById("otaType").textContent = "-";
  document.getElementById("otaMessage").textContent = "Geen";

  // Nieuwe versies opnieuw ophalen
  setTimeout(() => {
    location.reload();
}, 500);
}

function toggleLock() {
  if (STATE.unlocked) {
    lock();
  } else {
    unlock();
  }
}

function savePinCode() {
  const val = document.getElementById("pinInput").value;

  if (val.length !== 4) {
    alert("PIN moet 4 cijfers zijn");
    return;
  }

  CONFIG.pin = val;
  saveConfig();

  alert("PIN opgeslagen.");
}

function saveTimeout() {
  CONFIG.ui.lockTimeout = parseInt(
    document.getElementById("timeoutInput").value || 30,
  );

  saveConfig();
}

function setAppName() {
  CONFIG.appName = document.getElementById("appNameInput").value;
  saveConfig();
  applyConfig();
}

function setColor(key, value) {
  CONFIG.ui.colors[key] = value;

  document.documentElement.style.setProperty(`--${key}`, value);

  saveConfig();
}

function setColorLive(key, value) {
  CONFIG.ui.colors[key] = value;

  document.documentElement.style.setProperty(`--${key}`, value);

  const preview = document.getElementById(`prev-${key}`);
  if (preview) preview.style.background = value;

  saveConfig();
}

function resetLockTimer() {
  if (!STATE.unlocked) return;

  clearTimeout(lockTimer);

  const t = CONFIG.ui.lockTimeout * 1000;

  lockTimer = setTimeout(() => {
    if (CONFIG.ui.kiosk) {
      lock(); // in kiosk altijd lock
    } else {
      lock();
    }
  }, t);
}

function closeAllMenus() {
  document
    .querySelectorAll(".node-menu")
    .forEach((m) => m.classList.remove("show"));
}
document.addEventListener("click", closeAllMenus);

function hideNode(id) {
  if (!CONFIG.hiddenNodes.includes(id)) CONFIG.hiddenNodes.push(id);
  saveConfig();
  renderPage();
}

// ===================== OTA Update =====================

// ===================== OTA =====================

function checkOTA() {

  fetch("/api/ota/check")

    .then(response => response.json())

    .then(data => {

      showOTAStatus(data);

    })

    .catch(err => {

      console.error("OTA check failed:", err);

    });

}


// ===========================================

function showOTAStatus(data) {

  if (!data) return;

  // ---------- Firmware ----------

  if (data.firmware) {

    document.getElementById("fwCurrent").textContent =
      data.firmware.current || "-";

    document.getElementById("fwAvailable").textContent =
      data.firmware.available || "-";

    if (data.firmware.update) {
      document.getElementById("fwStatus").textContent =
        "🟠 Update beschikbaar";

      document.getElementById("btnFirmware").disabled = false;
    }
    else {
      document.getElementById("fwStatus").textContent =
        "🟢 Actueel";

      document.getElementById("btnFirmware").disabled = true;

      // reset progress na afgeronde update
      /*
      document.getElementById("fwProgress").style.width = "0%";
      document.getElementById("fwProgressText").textContent = "0%";
      */
    }

  }


  // ---------- Website ----------

  if (data.web) {

    document.getElementById("webCurrent").textContent =
      data.web.current || "-";

    document.getElementById("webAvailable").textContent =
      data.web.available || "-";

    if (data.web.update) {
      document.getElementById("webStatus").textContent =
        "🟠 Update beschikbaar";

      document.getElementById("btnWebsite").disabled = false;
    }
    else {
      document.getElementById("webStatus").textContent =
        "🟢 Actueel";

      document.getElementById("btnWebsite").disabled = true;

      // reset progress na afgeronde update
      document.getElementById("webProgress").style.width = "0%";
      document.getElementById("webProgressText").textContent = "0%";
    }

  }

}


// ===========================================

function updateFirmware() {

  if (!confirm(
    "Firmware updaten?\n\nDe ESP32 zal daarna opnieuw opstarten."
  ))
    return;


  fetch("/api/ota/update/firmware",
    {
      method: "POST"
    })

    .catch(console.error);

}


// ===========================================

function updateWebsite() {

  if (!confirm(
    "Webinterface updaten?"
  ))
    return;


  fetch("/api/ota/update/web",
    {
      method: "POST"
    })

    .catch(console.error);

}


// ===========================================

function updateOTA(data) {
  console.log("updateOTA()", data);
  /*console.log("OTA DATA:", JSON.stringify(data));*/
  if (!data)
    return;

  // Firmware
  if (data.firmware) {
    console.log("FW progress update:", data.firmware.progress);
    document.getElementById("fwProgress").style.width =
      data.firmware.progress + "%";

    document.getElementById("fwProgressText").textContent =
      data.firmware.progress + "%";

    document.getElementById("fwStatus").textContent =
      data.firmware.status;
  }

  // Website
  if (data.web) {
    document.getElementById("webProgress").style.width =
      data.web.progress + "%";

    document.getElementById("webProgressText").textContent =
      data.web.progress + "%";

    document.getElementById("webStatus").textContent =
      data.web.status;
    
    if (data.type === "ota" && data.done === true) {
    resetUIAfterOTA();
}
  }
}

// ===================== SCREEN FUNCTIONS =====================

function showPage(id) {
  document.querySelectorAll(".page").forEach((p) => {
    p.classList.remove("active");
  });

  const target = document.getElementById(id);

  if (!target) {
    console.warn("[NAV] page not found:", id);
    return;
  }

  target.classList.add("active");
}

function toggleFullscreen() {
  const isFs = document.fullscreenElement;

  if (!isFs) {
    document.documentElement.requestFullscreen?.();
    CONFIG.ui.fullscreen = true;
  } else {
    document.exitFullscreen?.();
    CONFIG.ui.fullscreen = false;
  }

  saveConfig();
  updateFsButton();
}

function updateFsButton() {
  const btn = document.getElementById("fsBtn");
  if (!btn) return;

  btn.textContent = document.fullscreenElement
    ? "Exit fullscreen"
    : "Enter fullscreen";
}

document.addEventListener("fullscreenchange", () => {
  CONFIG.ui.fullscreen = !!document.fullscreenElement;
  saveConfig();
  updateFsButton();
});

function toggleKiosk() {
  CONFIG.ui.kiosk = !CONFIG.ui.kiosk;
  saveConfig();

  applyKioskState();
}

function applyKioskState() {
  const btn = document.getElementById("kioskBtn");

  if (btn) {
    btn.textContent = CONFIG.ui.kiosk ? "Disable kiosk" : "Enable kiosk";
  }

  if (CONFIG.ui.kiosk) {
    enterKiosk();
  } else {
    exitKiosk();
  }
}

function exitKiosk() {
  if (document.fullscreenElement) {
    document.exitFullscreen?.();
  }
}

function enterKiosk() {
  // 1. fullscreen forceren
  document.documentElement.requestFullscreen?.();

  // 2. lock bij start (optioneel direct locken)
  lock();
}

// ===================== NODE UPDATE =====================
function updateNodes(list) {
  nodes = {};

  list.forEach((n) => {
    CONFIG.hiddenNodes = CONFIG.hiddenNodes.filter((h) => h != n.id);
    nodes[n.id] = n;
  });

  renderPage();
}

// ===================== SEND COMMAND =====================
function send(cmd) {
  if (!ws || ws.readyState !== 1) return;
  addLog("TX", cmd);
  ws.send(JSON.stringify(cmd));
}

// ===================== RELAY TOGGLE =====================
function toggleRelay(nodeId, relayIndex) {
  const node = nodes[nodeId];
  if (!node) return;

  const current = node.relayState?.[relayIndex] || 0;
  const newState = current === 1 ? 0 : 1;

  send({
    cmd: "relay",
    id: nodeId,
    type: node.type,
    relay: relayIndex,
    state: newState,
  });
}

// ===================== RENAME NODE =====================
function renameNode(nodeId) {
  const name = prompt("Nieuwe naam:");
  if (!name) return;

  send({
    cmd: "rename",
    id: nodeId,
    type: nodes[nodeId].type,
    name: name,
  });
}

// ===================== RENDER ROOT =====================
const root = document.getElementById("app");

// ===================== NODE BODY =====================
function renderBody(node) {
  // SENSOR NODE
  if (node.type === 0) {
    return `
        <div class="sensor-box">
          <div>🌡 Temp: ${node.temperature?.toFixed(1) ?? "-"} °C</div>
          <div>💧 Hum: ${node.humidity?.toFixed(1) ?? "-"} %</div>
        </div>
      `;
  }

  // RELAY NODE
  if (node.type === 1) {
    let html = `
        <div class="relay-box">
      `;

    const relays = node.relayState || [];

    relays.forEach((state, index) => {
      html += `
          <div class="relay">

            <span>
              ${CONFIG.relays[node.id]?.names[index] || "Relay " + (index + 1)}
            </span>


            <button onclick="toggleRelay('${node.id}', ${index})">

              ${state ? "ON" : "OFF"}

            </button>

          </div>
        `;
    });

    html += `
        </div>
      `;

    return html;
  }

  return `<div>Unknown node type</div>`;
}

function renderRelaySettings() {
  const container = document.getElementById("relaySettingsContainer");
  if (!container) return;

  container.innerHTML = "";

  Object.values(nodes || {}).forEach((node) => {
    if (node.type !== 1) return;

    const nodeId = node.id;

    if (!CONFIG.relays[nodeId]) {
      CONFIG.relays[nodeId] = {
        names: ["Relay 1", "Relay 2", "Relay 3", "Relay 4"],

        modes: ["toggle", "toggle", "toggle", "toggle"], // ✅ HIER wijzigen
      };
    }

    const cfg = CONFIG.relays[nodeId];

    while (cfg.names.length < 4) {
      cfg.names.push("Relay " + (cfg.names.length + 1));
    }

    while (cfg.modes.length < 4) {
      cfg.modes.push("toggle");
    }

    const card = document.createElement("div");
    card.className = "card";

    card.innerHTML = `
        <h3>${node.name || nodeId}</h3>

        <input id="r_${nodeId}_0" value="${cfg.names[0] || "Relay 1"}">
        <input id="r_${nodeId}_1" value="${cfg.names[1] || "Relay 2"}">
        <input id="r_${nodeId}_2" value="${cfg.names[2] || "Relay 3"}">
        <input id="r_${nodeId}_3" value="${cfg.names[3] || "Relay 4"}">

        <select id="m_${nodeId}_0">
        <option value="toggle">Toggle</option>
        <option value="momentary">Momentary</option>
        </select>

        <select id="m_${nodeId}_1">
        <option value="toggle">Toggle</option>
        <option value="momentary">Momentary</option>
        </select>

        <select id="m_${nodeId}_2">
        <option value="toggle">Toggle</option>
        <option value="momentary">Momentary</option>
        </select>

        <select id="m_${nodeId}_3">
        <option value="toggle">Toggle</option>
        <option value="momentary">Momentary</option>
        </select>

        <button onclick="saveRelayNode('${nodeId}')">Opslaan</button>
      `;

    container.appendChild(card);
  });
}

function saveRelayNode(nodeId) {
  CONFIG.relays[nodeId] = {
    names: [
      document.getElementById(`r_${nodeId}_0`).value,
      document.getElementById(`r_${nodeId}_1`).value,
      document.getElementById(`r_${nodeId}_2`).value,
      document.getElementById(`r_${nodeId}_3`).value,
    ],

    modes: [
      document.getElementById(`m_${nodeId}_0`).value,
      document.getElementById(`m_${nodeId}_1`).value,
      document.getElementById(`m_${nodeId}_2`).value,
      document.getElementById(`m_${nodeId}_3`).value,
    ],
  };

  saveConfig();
}

// ===================== UI CACHE =====================
const domNodes = {};

// ===================== RENDER (OPTIMIZED) =====================
function renderNodes() {
  const homeRoot = document.getElementById("homeRelayRoot");
  const relayPageRoot = document.getElementById("relayRoot");

  if (!homeRoot || !relayPageRoot) return;

  homeRoot.innerHTML = "";
  relayPageRoot.innerHTML = "";

  Object.values(nodes).forEach((node) => {
    if (CONFIG.hiddenNodes.includes(node.id)) return;

    // alleen relais tonen
    if (node.type !== 1) return;

    const card = createNodeCard(node);

    updateNodeCard(card, node);

    // Home overzicht
    homeRoot.appendChild(card.cloneNode(true));

    // Volledige relaispagina
    relayPageRoot.appendChild(card);
  });
}

function renderPage() {
  const page = getActivePage();

  // relais altijd bijwerken
  renderNodes();

  if (page === "sensors") {
    renderSensorPage();
  }

  if (page === "status") {
    renderStatusPage();
  }

  if (page === "settings") {
    renderRelaySettings();
  }
}

function getActivePage() {
  const pages = document.querySelectorAll(".page");
  for (const p of pages) {
    if (p.classList.contains("active")) return p.id;
  }
  return "home";
}

function renderSensorPage() {
  const root = document.getElementById("sensorsRoot");
  if (!root) return;

  root.innerHTML = "";

  Object.values(nodes).forEach((node) => {
    if (node.type !== 0) return;

    const el = createNodeCard(node);
    root.appendChild(el);
    updateNodeCard(el, node);
  });
}

function renderStatusPage() {
  const root = document.getElementById("statusRoot");
  if (!root) return;

  const online = Object.values(nodes).filter((n) => n.status === 1).length;
  const offline = Object.values(nodes).filter((n) => n.status === 0).length;

  root.innerHTML = `
      <div class="card">
        <h3>Status</h3>
        <p>Online: ${online}</p>
        <p>Offline: ${offline}</p>
        <p>Totaal: ${Object.keys(nodes).length}</p>
      </div>
    `;
}

// ===================== CREATE CARD =====================
function createNodeCard(node) {
  const card = document.createElement("div");
  card.className = "node-card";
  card.id = `node-${node.id}`;

  card.innerHTML = `
      <div class="node-header">
        <div class="node-title"></div>
        <div class="node-status"></div>
      </div>

      <div class="node-meta">
        <div class="node-id"></div>
        <div class="node-rssi"></div>
        <div class="node-lastseen"></div>
      </div>

      <div class="node-body"></div>

      <div class="node-actions">
        <button class="rename-btn">Rename</button>
      </div>
    `;

  // events
  const renameBtn = card.querySelector(".rename-btn");
  if (renameBtn) {
    renameBtn.onclick = () => {
      renameNode(node.id);
    };
  }
  domNodes[node.id] = card;
  return card;
}

/*===================== UPDATE CARD =====================*/

function updateWifiInfo(data) {
  if (!data) return;

  const ssid =
    document.getElementById("wifiSSID");
  const status =
    document.getElementById("wifiStatus");
  const ip =
    document.getElementById("wifiIP");
  const rssi =
    document.getElementById("wifiRSSI");
  const quality =
    document.getElementById("wifiQuality");

  if (ssid)
    ssid.textContent = data.ssid || "-";

  if (ip)
    ip.textContent = data.ip || "-";

  if (data.connected) {

    if (status)
      status.textContent = "Connected";

    if (rssi)
      rssi.textContent =
        typeof data.rssi === "number"
          ? data.rssi + " dBm"
          : "-";

    let q = "-";

    if (data.rssi >= -50)
      q = "Excellent";
    else if (data.rssi >= -60)
      q = "Very Good";
    else if (data.rssi >= -70)
      q = "Good";
    else if (data.rssi >= -80)
      q = "Fair";
    else
      q = "Poor";

    if (quality)
      quality.textContent = q;

  }
  else {

    if (status)
      status.textContent = "Disconnected";

    if (rssi)
      rssi.textContent = "-";

    if (quality)
      quality.textContent = "-";
  }
}

// ===================== UPDATE CARD =====================
function updateNodeCard(el, node) {
  const isOnline = node.status === 1;

  el.querySelector(".node-title").textContent = node.name || "Node";

  el.querySelector(".node-status").textContent = isOnline
    ? "ONLINE"
    : "OFFLINE";
  el.querySelector(".node-status").className =
    "node-status " + (isOnline ? "online" : "offline");

  el.querySelector(".node-id").textContent = "ID: " + node.id;
  el.querySelector(".node-rssi").textContent = "RSSI: " + (node.rssi ?? "-");

  el.querySelector(".node-body").innerHTML = renderBody(node);

  el.dataset.lastSeen = node.lastSeen;
}

// ===================== Show Node Info =====================

function showNodeInfo(id) {
  const node = nodes[id];
  if (!node) return;
  document.getElementById("nodeInfoContent").innerHTML = `

    <table>
    <tr><td><b>Naam</b></td><td>${node.name}</td></tr>
    <tr><td><b>ID</b></td><td>${node.id}</td></tr>
    <tr><td><b>Type</b></td><td>${node.type == 0 ? "Sensor" : "Relay"}</td></tr>
    <tr><td><b>Status</b></td><td>${node.status ? "ONLINE" : "OFFLINE"}</td></tr>
    <tr><td><b>RSSI</b></td><td>${node.rssi ?? "-"}</td></tr>
    <tr><td><b>Last seen</b></td><td>${new Date(
    node.lastSeen,
  ).toLocaleString()}</td></tr>
    </table>
    `;
  document.getElementById("nodeInfoModal").classList.add("show");
}

function closeNodeInfo() {
  document.getElementById("nodeInfoModal").classList.remove("show");
}

// ===================== LIVE UI TICK =====================
function updateLiveUI() {
  Object.values(nodes).forEach((node) => {
    const el = domNodes[node.id];
    if (!el) return;

    const lastSeenEl = el.querySelector(".node-lastseen");

    const diff = Date.now() - (node.lastSeen || 0);

    let text = "just now";

    if (diff > 1000) text = Math.floor(diff / 1000) + "s ago";
    if (diff > 60000) text = Math.floor(diff / 60000) + "m ago";

    lastSeenEl.textContent = "Last seen: " + text;

    // OFFLINE FORCE CHECK (UI ONLY)
    const isOffline = diff > 30000;
    const statusEl = el.querySelector(".node-status");

    if (isOffline) {
      statusEl.textContent = "OFFLINE";
      statusEl.className = "node-status offline";
    }
  });
}

// ===================== CONNECTION STATUS =====================
function setConnectionStatus(ok) {
  const el = document.getElementById("connectionStatus");
  if (!el) return;

  el.textContent = ok ? "CONNECTED" : "DISCONNECTED";
  el.className = ok ? "ok" : "bad";
}

// ===================== BOOT =====================

window.addEventListener("DOMContentLoaded", () => {
  bindNavigation();
  bindHeader();
  initLockscreen();

  loadConfig();
  showPage("home");
  if (CONFIG.ui.kiosk) {
    applyKioskState();
  }

  connectWS();

  // 👉 HIER toevoegen:
  document.querySelectorAll(".home-card").forEach((el) => {
    el.addEventListener("click", () => showPage(el.dataset.page));
  });

  ["click", "mousemove", "keydown", "touchstart"].forEach((evt) => {
    document.addEventListener(evt, resetLockTimer);
  });

  setInterval(updateLiveUI, 1000);
});

// Auto re-fullscreen als user eruit gaat
document.addEventListener("fullscreenchange", () => {
  if (CONFIG.ui.kiosk && !document.fullscreenElement) {
    document.documentElement.requestFullscreen?.();
  }
});
